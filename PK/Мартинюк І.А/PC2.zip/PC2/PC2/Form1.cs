using System.Text.RegularExpressions;

namespace PC2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            radioButton1.Checked = true;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridView1.AutoResizeColumns();
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView1.AutoResizeRows(DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders);
            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;
        }

        private static readonly SortedList<string, double> letterFrequencies = new(){
            {"�", 0.10983},
            {"�", 0.08483},
            {"�", 0.07998},
            {"�", 0.07367},
            {"�", 0.067},
            {"�", 0.06318},
            {"�", 0.05473},
            {"�", 0.04746},
            {"�", 0.04533},
            {"�", 0.04343},
            {"�", 0.03486},
            {"�", 0.03203},
            {"�", 0.02977},
            {"�", 0.02804},
            {"�", 0.02615},
            {"�", 0.02001},
            {"�", 0.01898},
            {"�", 0.01735},
            {"�", 0.01687},
            {"�", 0.01641},
            {"�", 0.01592},
            {"�", 0.0145},
            {"�", 0.01208},
            {"�", 0.00966},
            {"�", 0.0094},
            {"�", 0.00718},
            {"�", 0.00639},
            {"�", 0.00486},
            {"�", 0.00361},
            {"�", 0.00331},
            {"�", 0.00267},
            {"�", 0.00037}
        };
        //������������ ������
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string text = textBox1.Text;
            text = text.ToLower();
            text = text.Replace("�", "e");
            textBox2.Text = new string(text.Where(c => char.IsLetter(c)).ToArray());
        }
        //�����������
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            label1.Text = "������ �����:";
            label2.Text = "³������������� �����:";
            label3.Text = "����:";
            button1.Text = "���������";
            label5.Text = "����������:";
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            dataGridView1.Visible = false;
            comboBox1.Visible = false;
            textBox3.Visible = true;
            textBox4.Visible = true;
            label5.Visible = true;
            label6.Visible = false;
            label7.Visible = false;
            textBox5.Visible = false;
            textBox6.Visible = false;
            button2.Visible = false;
            comboBox2.Visible = false;
        }
        // ������������
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            label1.Text = "������ ����������:";
            label2.Text = "³������������� ����������:";
            label3.Text = "����:";
            button1.Text = "������������";
            label5.Text = "�����:";
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            comboBox1.Visible = false;
            dataGridView1.Visible = false;
            textBox3.Visible = true;
            textBox4.Visible = true;
            label5.Visible = true;
            label6.Visible = false;
            label7.Visible = false;
            textBox5.Visible = false;
            textBox6.Visible = false;
            button2.Visible = false;
            comboBox2.Visible = false;
        }
        //���������� ������� ����������
        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            label1.Text = "������ �����:";
            label2.Text = "³������������� �����:";
            label3.Text = "�����:";
            button1.Text = "���������";
            label5.Text = "�����������:";
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox3.Visible = true;
            textBox4.Visible = true;
            label5.Visible = true;
            comboBox1.Visible = false;
            dataGridView1.Visible = true;
            dataGridView1.Columns[0].HeaderText = "����";
            dataGridView1.Rows.Clear();
            label6.Visible = false;
            label7.Visible = false;
            textBox5.Visible = false;
            textBox6.Visible = false;
            button2.Visible = false;
            comboBox2.Visible = false;
        }
        //����������� �����
        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            label1.Text = "������ ����������:";
            label2.Text = "³������������� ����������:";
            button1.Text = "ϳ������";
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            label3.Text = "����� ������ �������:";
            textBox3.Visible = false;
            textBox4.Visible = false;
            label5.Visible = false;
            dataGridView1.Visible = true;
            comboBox1.Visible = true;
            dataGridView1.Columns[0].HeaderText = "������� �����";
            dataGridView1.Rows.Clear();
            label6.Visible = true;
            label7.Visible = true;
            textBox5.Visible = true;
            textBox6.Visible = true;
            button2.Visible = true;
            comboBox2.Visible = true;
        }
        //������������ �����
        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            string text = textBox3.Text;
            text = text.ToLower();
            text = text.Replace("�", "e");
            textBox3.Text = new string(text.Where(c => char.IsLetter(c)).ToArray());
        }
        //������                                         ��������������������������������
        private static readonly string russianAlphabet = "��������������������������������";
        //������1
        private void button1_Click(object sender, EventArgs e)
        {
            label4.Text = "";
            string text = textBox3.Text;
            text = text.ToLower();
            if (textBox3.Text != Regex.Replace(text, "[^�-��-�]", "").Trim() && !radioButton3.Checked)
            {
                label4.Text = "������������ ����!";
                return;
            }
            if (radioButton1.Checked)
            {
                textBox4.Text = Encrypt(textBox2.Text, textBox3.Text);
            }
            else if (radioButton2.Checked)
            {
                textBox4.Text = Decrypt(textBox2.Text, textBox3.Text);
            }
            else if (radioButton3.Checked)
            {
                StatTextualCoherenceIndex();
            }
            else
            {
                FindKey(textBox2.Text, comboBox1.SelectedIndex);
            }
        }
        //������ ��������� �����
        private void button2_Click(object sender, EventArgs e)
        {
            textBox6.Text = string.Empty;

            string temp = textBox2.Text;
            bool allSubstringsAdded;
            List<string> substrings = new();
            if ((textBox5.Text != Regex.Replace(textBox5.Text, "[^0-9]", "").Trim()) || Regex.Replace(textBox5.Text, "[^0-9]", "").Trim() == "")
            {
                return;
            }

            int keyLength = Convert.ToInt32(textBox5.Text);
            do
            {
                if (temp.Length <= keyLength)
                {
                    substrings.Add(temp);
                    allSubstringsAdded = true;
                }
                else
                {
                    substrings.Add(temp[..Convert.ToInt32(textBox5.Text)]);
                    temp = temp[Convert.ToInt32(textBox5.Text)..];
                    allSubstringsAdded = false;
                }
            } while (!allSubstringsAdded);
            if (comboBox2.SelectedIndex == 0)
            {
                string key = "";
                for (int i = 0; i < keyLength; i++)
                {
                    string block = "";
                    foreach (string str in substrings)
                    {
                        if (!substrings[^1].Equals(str))
                        {
                            block += str[i];
                        }
                    }
                    string mostCommonStr = block
                    .GroupBy(c => c)
                    .OrderByDescending(g => g.Count())
                    .Select(g => g.Key)
                    .FirstOrDefault().ToString();
                    int letterInt = (russianAlphabet.IndexOf(mostCommonStr) - russianAlphabet.IndexOf("�")) % 32;
                    string letter = russianAlphabet[letterInt >= 0 ? letterInt : letterInt + 32].ToString();
                    key += letter;
                }
                textBox6.Text = "����: " + key;
            }
            else
            {
                string key = "";
                for (int i = 0; i < keyLength; i++)
                {
                    string block = "";
                    foreach (string str in substrings)
                    {
                        if (!substrings[^1].Equals(str))
                        {
                            block += str[i];
                        }
                    }
                    SortedList<string, double> letters = new();
                    for (int g = 0; g < 32; g++)
                    {
                        double sum = 0;
                        for (int t = 0; t < 32; t++)
                        {
                            sum += letterFrequencies.GetValueOrDefault(letterFrequencies.Keys[t].ToString()) * block.Count(c => c == russianAlphabet[(g + t) % 32]);
                        }
                        letters.Add(russianAlphabet[g].ToString(), sum);
                    }
                    double maxValue = letters.Values.Max();
                    string maxKey = letters.FirstOrDefault(x => x.Value == maxValue).Key;
                    key += maxKey;
                    textBox6.Text += maxKey + " - " + maxValue + Environment.NewLine;
                }
                textBox6.Text += "����: " + key;
            }
        }
        // ������� ����
        private static SortedList<string, double> GetLetterFrequencies(string text)
        {
            int totalLetters = text.Count(char.IsLetter);
            Dictionary<char, int> letterCounts = new();

            foreach (char c in text)
            {
                if (char.IsLetter(c))
                {
                    char lowerC = char.ToLower(c);

                    if (letterCounts.ContainsKey(lowerC))
                    {
                        letterCounts[lowerC]++;
                    }
                    else
                    {
                        letterCounts.Add(lowerC, 1);
                    }
                }
            }

            SortedList<string, double> frequencies = new();

            foreach (KeyValuePair<char, int> kvp in letterCounts)
            {
                double frequency = (double)kvp.Value / totalLetters * 100.0;
                frequencies.Add(kvp.Key.ToString(), frequency);
            }

            return frequencies;
        }
        // ����������
        public static string Encrypt(string text, string key)
        {
            string result = "";
            int keyIndex = 0;
            int alphabetSize = russianAlphabet.Length;

            for (int i = 0; i < text.Length; i++)
            {
                char currentChar = text[i];
                char currentKeyChar = key[keyIndex];
                int charIndex = russianAlphabet.IndexOf(currentChar);
                int keyIndexInAlphabet = russianAlphabet.IndexOf(currentKeyChar);
                int encryptedIndex = (charIndex + keyIndexInAlphabet) % alphabetSize;
                char encryptedChar = russianAlphabet[encryptedIndex];
                result += encryptedChar;
                keyIndex++;
                if (keyIndex == key.Length)
                {
                    keyIndex = 0;
                }
            }

            return result;
        }
        //�������������
        public static string Decrypt(string text, string key)
        {
            string result = "";
            int alphabetSize = russianAlphabet.Length;
            int[] keyIndexes = new int[key.Length];

            for (int i = 0; i < key.Length; i++)
            {
                keyIndexes[i] = russianAlphabet.IndexOf(key[i]);
            }

            for (int i = 0; i < text.Length; i++)
            {
                char currentChar = text[i];
                int charIndex = russianAlphabet.IndexOf(currentChar);
                int keyIndex = keyIndexes[i % key.Length];
                int decryptedIndex = (charIndex - keyIndex + alphabetSize) % alphabetSize;
                result += russianAlphabet[decryptedIndex];
            }
            return result;
        }
        //���������� ������� ����������
        private void StatTextualCoherenceIndex()
        {
            string[] keys = textBox3.Text.Split(' ');
            string encrypts = "";
            SortedList<string, double> textualCoherenceIndex = new();
            for (int i = 0; i < keys.Length; i++)
            {
                string encryptedText = Encrypt(textBox2.Text, keys[i]);
                encrypts += $"Key: \"{keys[i]}\"{Environment.NewLine}" +
                    $"Encrypted text:{Environment.NewLine}" +
                    $"{encryptedText}" +
                    $"{Environment.NewLine}{Environment.NewLine}{Environment.NewLine}";
                textualCoherenceIndex.Add(keys[i], TextualCoherenceIndex(encryptedText.Length, SymbolCount(encryptedText)));
            }
            FillTable(textualCoherenceIndex);
            textBox4.Text = encrypts;
        }
        //������� ������� ������� � �����
        private SortedList<string, int> SymbolCount(string text)
        {
            char[] sym = text.ToCharArray();
            SortedList<string, int> result = new();
            for (int i = 0; i < sym.Length; i++)
            {
                if (result.Keys.Contains(sym[i].ToString()))
                {
                    ++result[sym[i].ToString()];
                }
                else
                {
                    result.Add(sym[i].ToString(), 1);
                }
            }
            return result;
        }
        //������ ���������� ������
        private double TextualCoherenceIndex(int charsCount, SortedList<string, int> stat)
        {
            double sum = 0;
            foreach (int v in stat.Values)
            {
                sum += v * (v - 1);
            }
            double result = (sum / ((charsCount * charsCount) - 1)) > 0 ? (sum / ((charsCount * charsCount) - 1)) : 0;
            return result;
        }
        //���������� �������
        private void FillTable(SortedList<string, double> list)
        {
            dataGridView1.Rows.Clear();
            IOrderedEnumerable<KeyValuePair<string, double>> sortedValues = list.OrderByDescending(x => x.Value);
            foreach (KeyValuePair<string, double> t in sortedValues)
            {
                dataGridView1.Rows.Add(t.Key, t.Value.ToString("F4"));
            }
        }
        //����������� �����
        private void FindKey(string encryptedText, int control)
        {
            if (control == 0)
            {
                SortedList<string, double> keyLenghtIndex = new();
                List<string> substrings = new();
                for (int i = 2; i <= 40; i++)
                {
                    string temp = encryptedText;
                    double sum = 0;
                    bool allSubstringsAdded;
                    do
                    {
                        if (temp.Length <= i)
                        {
                            substrings.Add(temp);
                            allSubstringsAdded = true;
                        }
                        else
                        {
                            substrings.Add(temp[..i]);
                            temp = temp[i..];
                            allSubstringsAdded = false;
                        }
                    } while (!allSubstringsAdded);

                    for (int j = 0; j < substrings.Count; j++)
                    {
                        sum += TextualCoherenceIndex(substrings[j].Length, SymbolCount(substrings[j]));
                    }
                    keyLenghtIndex.Add(i.ToString(), (double)sum / substrings.Count);
                    substrings.Clear();
                }

                FillTable(keyLenghtIndex);
            }
            else
            {
                SortedList<string, double> keySamenessIndex = new();
                for (int i = 2; i <= 40; i++)
                {
                    int sum = 0;
                    for (int j = 0; j < encryptedText.Length - i; j++)
                    {
                        sum += encryptedText[j] == encryptedText[j + i] ? 1 : 0;
                    }
                    keySamenessIndex.Add(i.ToString(), sum);
                }
                FillTable(keySamenessIndex);
            }
        }
        //�������� ������ � �����
        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new()
            {
                Filter = "������� ����� (*.txt)|*.txt"
            };
            open.ShowDialog(this);
            if (open.FileName.Length == 0)
            {
                return;
            }
            StreamReader sr = new(open.FileName);
            textBox1.Text = "";
            while (!sr.EndOfStream)
            {
                string line = sr.ReadLine();
                textBox1.Text += line + Environment.NewLine;
            }
            sr.Close();
        }
    }
}