using System.Text.RegularExpressions;

namespace PC1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            comboBox1.SelectedIndex = 0;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridView1.AutoResizeColumns();
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView1.AutoResizeRows(DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders);

        }
        //�����������
        private void button1_Click(object sender, EventArgs e)
        {
            string text = textBox1.Text;
            text = text.ToLower();
            text = text.Replace("�", "e");
            textBox2.Text = radioButton1.Checked
                ? new string(text.Where(c => char.IsLetter(c)).ToArray())
                : Regex.Replace(Regex.Replace(text, "[^�-�a-z�-����]", " ").Trim(), "[ ]+", " ");
            label4.Text = TextMatchingIndex(textBox2.Text.Length, countSymbols(textBox2.Text)).ToString("F4");
        }
        //�������� �������
        private void button2_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox2.Text))
            {
                switch (comboBox1.SelectedIndex)
                {
                    case 0:
                        FillTable(statSym(textBox2.Text)); break;
                    case 1:
                        FillTable(statBigramWith�ntersection(textBox2.Text)); break;
                    case 2:
                        FillTable(statBigramWithout�ntersection(textBox2.Text)); break;
                }
            }
        }
        //������� ������� 
        private SortedList<string, double> statSym(string text)
        {
            char[] sym = text.ToCharArray();
            SortedList<string, int> countSymbols = new();
            for (int i = 0; i < sym.Length; i++)
            {
                if (countSymbols.Keys.Contains(sym[i].ToString()))
                {
                    ++countSymbols[sym[i].ToString()];
                }
                else
                {
                    countSymbols.Add(sym[i].ToString(), 1);
                }
            }
            SortedList<string, double> result = new();
            foreach (KeyValuePair<string, int> t in countSymbols)
            {
                result.Add(t.Key, t.Value / (double)sym.Length * 100);
            }
            return result;
        }
        //������� ����� ��� ��������
        private SortedList<string, double> statBigramWithout�ntersection(string text)
        {
            char[] sym = text.ToCharArray();
            List<string> bigrams = new();
            for (int i = 0; i < sym.Length - 1; i += 2)
            {
                if (sym[i].ToString().Equals(" "))
                {
                    i++;
                }
                if (i == sym.Length - 1)
                {
                    break;
                }
                if ((!sym[i].ToString().Equals(" ")) && !sym[i + 1].ToString().Equals(" "))
                {
                    bigrams.Add(sym[i].ToString() + sym[i + 1].ToString());
                }
            }
            SortedList<string, int> count = new();
            int bCount = bigrams.Count;
            while (bigrams.Count > 0)
            {
                string str = bigrams[0];
                count.Add(str, bigrams.Count(n => n == str));
                bigrams.RemoveAll(m => m == str);
            }
            SortedList<string, double> result = new();
            foreach (KeyValuePair<string, int> t in count)
            {
                result.Add(t.Key, t.Value / (double)bCount * 100);
            }
            return result;
        }
        //������� ����� � ���������
        private SortedList<string, double> statBigramWith�ntersection(string text)
        {
            char[] sym = text.ToCharArray();
            List<string> bigrams = new();
            for (int i = 0; i < sym.Length - 1; i++)
            {
                if ((!sym[i].ToString().Equals(" ")) && !sym[i + 1].ToString().Equals(" "))
                {
                    bigrams.Add(sym[i].ToString() + sym[i + 1].ToString());
                }
            }
            SortedList<string, int> count = new();
            int bCount = bigrams.Count;
            while (bigrams.Count > 0)
            {
                string str = bigrams[0];
                count.Add(str, bigrams.Count(n => n == str));
                bigrams.RemoveAll(m => m == str);
            }
            SortedList<string, double> result = new();
            foreach (KeyValuePair<string, int> t in count)
            {
                result.Add(t.Key, t.Value / (double)bCount * 100);
            }
            return result;
        }
        //������� ������� � �����
        private SortedList<string, int> countSymbols(string text)
        {
            char[] sym = text.ToCharArray();
            SortedList<string, int> result = new();
            for (int i = 0; i < sym.Length; i++)
            {
                if (result.Keys.Contains(sym[i].ToString()))
                {
                    ++result[sym[i].ToString()];
                }
                else
                {
                    result.Add(sym[i].ToString(), 1);
                }
            }
            return result;
        }
        //������ ���������� ������
        private double TextMatchingIndex(int charsCount, SortedList<string, int> stat)
        {
            int sum = 0;
            foreach (int v in stat.Values)
            {
                sum += v * (v - 1);
            }
            return sum / (double)((charsCount * charsCount) - 1);
        }
        //���������� �������
        private void FillTable(SortedList<string, double> list)
        {
            dataGridView1.Rows.Clear();
            IOrderedEnumerable<KeyValuePair<string, double>> sortedValues = list.OrderByDescending(x => x.Value);
            foreach (KeyValuePair<string, double> t in sortedValues)
            {
                dataGridView1.Rows.Add(t.Key, t.Value.ToString("F4"));
            }
        }
        //������� � �����
        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new()
            {
                Filter = "������� ����� (*.txt)|*.txt"
            };
            open.ShowDialog(this);
            if (open.FileName.Length == 0)
            {
                return;
            }
            StreamReader sr = new(open.FileName);
            textBox1.Text = "";
            while (!sr.EndOfStream)
            {
                string line = sr.ReadLine();
                textBox1.Text += line + Environment.NewLine;
            }
            sr.Close();
        }
    }
}